package com.oyunceviri.app

import android.content.Context
import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Tüm ayarlar burada saklanır. Servis her taramada buradan okur, yani ayar değişince anında geçerli olur. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ayar", Context.MODE_PRIVATE)

    var useGemini: Boolean
        get() = sp.getBoolean("gem", false)
        set(v) { sp.edit().putBoolean("gem", v).apply() }

    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) { sp.edit().putString("key", v.trim()).apply() }

    var model: String
        get() = sp.getString("model", "") ?: ""
        set(v) { sp.edit().putString("model", v.trim()).apply() }

    var srcLang: String
        get() = sp.getString("src", "en") ?: "en"
        set(v) { sp.edit().putString("src", v).apply() }

    var intervalMs: Int
        get() = sp.getInt("interval2", 500)
        set(v) { sp.edit().putInt("interval2", v).apply() }

    var textSp: Int
        get() = sp.getInt("textsp", 16)
        set(v) { sp.edit().putInt("textsp", v).apply() }

    var bgAlpha: Int
        get() = sp.getInt("alpha", 92)
        set(v) { sp.edit().putInt("alpha", v).apply() }

    /** true: kutu orijinal altyazıyı örter (hafif titreme yapar). false: kutu çerçevenin hemen üstüne çıkar, titremez. */
    var cover: Boolean
        get() = sp.getBoolean("cover", false)
        set(v) { sp.edit().putBoolean("cover", v).apply() }

    /** Çerçeve ekranın oranı olarak saklanır: x, y, genişlik, yükseklik. Dikey ve yatay için ayrı. */
    fun frame(landscape: Boolean): FloatArray? {
        val s = sp.getString(if (landscape) "fr_l" else "fr_p", null) ?: return null
        val parts = s.split(",").mapNotNull { it.toFloatOrNull() }
        return if (parts.size == 4) parts.toFloatArray() else null
    }

    fun setFrame(landscape: Boolean, f: FloatArray) {
        sp.edit().putString(if (landscape) "fr_l" else "fr_p", f.joinToString(",")).apply()
    }

    fun clearFrames() {
        sp.edit().remove("fr_l").remove("fr_p").apply()
    }
}

object Langs {
    val list = listOf(
        "İngilizce" to "en",
        "Almanca" to "de",
        "Fransızca" to "fr",
        "İspanyolca" to "es",
        "İtalyanca" to "it",
        "Portekizce" to "pt"
    )
    private val eng = mapOf(
        "en" to "English", "de" to "German", "fr" to "French", "es" to "Spanish",
        "it" to "Italian", "pt" to "Portuguese"
    )

    fun english(code: String): String = eng[code] ?: code
}

class GeminiError(val code: Int, val body: String) : Exception("HTTP $code")

/** Ekrandan okunan görüntüyü metne çevirir (cihaz içi, ücretsiz, kota yok). */
class Ocr {
    private var rec: TextRecognizer? = null

    /** Latin alfabesi (İngilizce ve Avrupa dilleri). Model uygulamanın içinde, internet gerekmez. */
    fun recognize(bmp: Bitmap, src: String): Text {
        val r = rec ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).also { rec = it }
        return Tasks.await(r.process(InputImage.fromBitmap(bmp, 0)))
    }

    fun close() {
        rec?.close()
    }
}

/**
 * Çeviri merkezi. Varsayılan ML Kit (cihaz içi, kotasız). Gemini açıksa önce onu dener,
 * hata alırsa (429, 404, anahtar sorunu) otomatik ML Kit'e düşer ve bir süre Gemini'yi bekletir.
 * Aynı cümle tekrar gelirse önbellekten verir, API'ye gitmez.
 */
class TranslatorHub(private val prefs: Prefs) {
    var onNote: ((String) -> Unit)? = null

    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 300
    }
    private var ml: Translator? = null
    private var mlLang = ""
    private var mlReady = false
    private var blockedUntil = 0L

    fun translate(text: String, src: String): String {
        val now = System.currentTimeMillis()
        val useG = prefs.useGemini && prefs.apiKey.isNotEmpty() && now >= blockedUntil
        val key = (if (useG) "g|" else "m|") + src + "|" + text
        cache[key]?.let { return it }

        var out: String? = null
        if (useG) {
            try {
                out = gemini(text, src)
                onNote?.invoke("Çalışıyor (Gemini)")
            } catch (e: GeminiError) {
                when (e.code) {
                    429 -> {
                        blockedUntil = now + 60_000
                        onNote?.invoke("Gemini kotası doldu, 60 sn ML Kit kullanılıyor")
                    }
                    404 -> {
                        blockedUntil = now + 300_000
                        onNote?.invoke("Gemini modeli bulunamadı. Ayarlardan 'Modelleri getir' ile seç")
                    }
                    400, 401, 403 -> {
                        blockedUntil = now + 300_000
                        onNote?.invoke("Gemini anahtarı reddedildi (${e.code}), ML Kit kullanılıyor")
                    }
                    else -> {
                        blockedUntil = now + 30_000
                        onNote?.invoke("Gemini hatası (${e.code}), geçici ML Kit")
                    }
                }
            } catch (e: Exception) {
                blockedUntil = now + 20_000
                onNote?.invoke("Gemini'ye ulaşılamadı, geçici ML Kit")
            }
        }
        val res: String = out?.takeIf { it.isNotBlank() } ?: mlkit(text, src)
        cache[key] = res
        return res
    }

    private fun mlkit(text: String, src: String): String {
        if (ml == null || mlLang != src) {
            ml?.close()
            ml = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.TURKISH)
                    .build()
            )
            mlLang = src
            mlReady = false
        }
        val t = ml!!
        if (!mlReady) {
            onNote?.invoke("Dil paketi indiriliyor, internet gerekli")
            Tasks.await(t.downloadModelIfNeeded(DownloadConditions.Builder().build()))
            mlReady = true
            onNote?.invoke("Çalışıyor (ML Kit)")
        }
        return Tasks.await(t.translate(text))
    }

    private fun gemini(text: String, src: String): String {
        val model = prefs.model.ifEmpty { "gemini-2.5-flash" }
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 8000
        c.readTimeout = 12000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", prefs.apiKey)

        val prompt = "Translate this video game subtitle from ${Langs.english(src)} to natural, fluent Turkish. " +
            "Keep character names and the tone. Output ONLY the Turkish translation, nothing else.\n\n" + text
        val body = JSONObject().put(
            "contents",
            JSONArray().put(
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            )
        )
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val resp = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        if (code !in 200..299) throw GeminiError(code, resp)

        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    fun close() {
        ml?.close()
    }
}

/** Anahtarınla gerçekten kullanabildiğin modelleri Google'dan sorar. 404 hatasının çaresi bu. */
fun listGeminiModels(key: String): List<String> {
    val c = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
        .openConnection() as HttpURLConnection
    c.connectTimeout = 8000
    c.readTimeout = 12000
    c.setRequestProperty("x-goog-api-key", key)
    val code = c.responseCode
    val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
    c.disconnect()
    if (code !in 200..299) throw GeminiError(code, txt)

    val arr = JSONObject(txt).optJSONArray("models") ?: return emptyList()
    val skip = listOf("image", "tts", "live", "audio", "embedding", "native", "robotics", "computer")
    val out = ArrayList<String>()
    for (i in 0 until arr.length()) {
        val m = arr.getJSONObject(i)
        val methods = m.optJSONArray("supportedGenerationMethods")
        var ok = false
        if (methods != null) {
            for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
        }
        val name = m.optString("name").removePrefix("models/")
        if (ok && name.startsWith("gemini") && skip.none { name.contains(it) }) out.add(name)
    }
    return out.sortedDescending()
}
