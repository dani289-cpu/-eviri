package com.oyunceviri.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Çeviri çerçevesi. Gövdesinden sürükleyince taşınır, sağ alttaki daireden sürükleyince boyutlanır,
 * Kaydet'e basınca konumu kaydedilir. Pencereyi taşıma işini servis yapar, bu sınıf sadece çizer ve dokunuşu bildirir.
 */
class FrameView(ctx: Context, private val cb: Callbacks) : View(ctx) {

    interface Callbacks {
        fun onMove(dx: Int, dy: Int)
        fun onResize(dw: Int, dh: Int)
        fun onSave()
    }

    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint().apply { color = Color.argb(50, 124, 92, 255) }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        color = 0xFF7C5CFF.toInt()
    }
    private val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF7C5CFF.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        color = Color.WHITE
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * d
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val saveRect = RectF(8f * d, 8f * d, 98f * d, 44f * d)

    private var mode = 0 // 0: yok, 1: taşı, 2: boyutlandır, 3: kaydet
    private var lastX = 0f
    private var lastY = 0f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRoundRect(0f, 0f, w, h, 10f * d, 10f * d, fill)
        c.drawRoundRect(1.5f * d, 1.5f * d, w - 1.5f * d, h - 1.5f * d, 10f * d, 10f * d, stroke)
        c.drawRoundRect(saveRect, 10f * d, 10f * d, accent)
        c.drawText("Kaydet", saveRect.centerX(), saveRect.centerY() + txt.textSize * 0.35f, txt)
        c.drawCircle(w - 20f * d, h - 20f * d, 12f * d, accent)
        c.drawCircle(w - 20f * d, h - 20f * d, 12f * d, ring)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                mode = when {
                    saveRect.contains(e.x, e.y) -> 3
                    hypot(e.x - (width - 20f * d), e.y - (height - 20f * d)) <= 30f * d -> 2
                    else -> 1
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                if (dx != 0 || dy != 0) {
                    if (mode == 1) {
                        cb.onMove(dx, dy)
                    } else if (mode == 2) {
                        cb.onResize(dx, dy)
                    }
                    lastX += dx
                    lastY += dy
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == 3 && saveRect.contains(e.x, e.y)) cb.onSave()
                mode = 0
            }
            MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }
}
