package com.oyunceviri.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/**
 * Akış: ekranı yakala -> SADECE kullanıcının çizdiği çerçeveyi kırp -> görüntü değişti mi bak ->
 * OCR -> iki okuma üst üste aynıysa çevir -> kutuyu göster.
 * Çeviri sadece metin gerçekten değişince yapılır, bu yüzden hem titreme hem API kotası sorunu olmaz.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_START = "oc.start"
        const val ACTION_STOP = "oc.stop"
        const val ACTION_TOGGLE = "oc.toggle"
        const val ACTION_FRAME = "oc.frame"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        @Volatile var running = false
        private const val TAG = "OyunCeviri"
    }

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private lateinit var hub: TranslatorHub
    private val ocr = Ocr()
    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var worker: Handler? = null

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var capW = 0
    private var capH = 0

    // Çeviri kutusu ve çerçeve düzenleyici (ikisi de ana thread'de yönetilir)
    private var box: TextView? = null
    private var editor: FrameView? = null
    private var editLp: WindowManager.LayoutParams? = null
    @Volatile private var boxShown = false
    @Volatile private var editing = false
    @Volatile private var paused = false
    private var originX = 0
    private var originY = 0
    private var note = "Çalışıyor"

    // Okuma durumu (sadece worker thread'de dokunulur)
    private var lastRegion: Bitmap? = null
    private var cropLeft = 0
    private var cropTop = 0
    private var prevSig: IntArray? = null
    private var doneSig: IntArray? = null
    private var blackCount = 0
    private var emptyCount = 0
    private var candNorm = ""
    private var candText = ""
    private var candRect = Rect()
    private var candCount = 0
    private var shownNorm = ""
    private var shownTextNorm = ""
    private var shownText = ""
    private var lastRect = Rect()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        hub = TranslatorHub(prefs)
        hub.onNote = { n -> setNote(n) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val i = intent ?: return START_NOT_STICKY
        when (i.action) {
            ACTION_STOP -> stopSelf()
            ACTION_TOGGLE -> {
                paused = !paused
                if (paused) clearBox() else worker?.post { resetReading() }
                notifyNow()
            }
            ACTION_FRAME -> if (running) toggleEditor()
            ACTION_START -> begin(i)
        }
        return START_NOT_STICKY
    }

    // ---------- Başlatma ----------

    private fun begin(intent: Intent) {
        if (running) return
        createChannel()
        val n = buildNotif()
        // Android 14+: önce foreground servis (mediaProjection tipinde), sonra getMediaProjection
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            legacyData(intent)
        }
        if (data == null) {
            stopSelf()
            return
        }

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), data)
            projection = mp
            // Android 14+: createVirtualDisplay'den ÖNCE callback kaydı zorunlu
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }, main)
            setupCapture()
        } catch (e: Exception) {
            Log.e(TAG, "capture", e)
            Toast.makeText(this, "Ekran yakalama başlatılamadı: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        running = true
        val t = HandlerThread("oc-worker")
        t.start()
        thread = t
        worker = Handler(t.looper).also { it.post(tick) }
    }

    @Suppress("DEPRECATION")
    private fun legacyData(i: Intent): Intent? = i.getParcelableExtra<Intent>(EXTRA_DATA)

    @Suppress("DEPRECATION")
    private fun realSize(): Triple<Int, Int, Int> {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun setupCapture() {
        val (w, h, d) = realSize()
        capW = w
        capH = h
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = projection!!.createVirtualDisplay(
            "oyunceviri", w, h, d,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    /** Ekran döndürülünce aynı VirtualDisplay'i yeniden boyutlandırır (Android 14+ yeni VirtualDisplay'e izin vermez). */
    private fun checkSize() {
        val (w, h, d) = realSize()
        if (w == capW && h == capH) return
        val old = reader
        val nr = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd?.resize(w, h, d)
        vd?.surface = nr.surface
        reader = nr
        old?.close()
        capW = w
        capH = h
        resetReading()
        clearBox()
        main.post { if (editor != null) closeEditor() }
    }

    // ---------- Ana döngü ----------

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Throwable) {
                Log.e(TAG, "step", e)
            }
            // Örtme modunda kutuyu her taramada gizlemek göz yorar, o yüzden daha seyrek tara
            val gap = if (prefs.cover && boxShown) max(prefs.intervalMs, 1500) else prefs.intervalMs
            worker?.postDelayed(this, gap.toLong())
        }
    }

    private fun grab(rd: ImageReader): Image? = try {
        rd.acquireLatestImage()
    } catch (e: Exception) {
        null
    }

    private fun step() {
        checkSize()
        if (paused || editing) return
        val rd = reader ?: return
        val fr = frameRect()
        if (fr == null) {
            setNote("Çerçeve yok: bildirimdeki 'Çerçeve' düğmesine bas")
            return
        }

        val cover = prefs.cover
        // Örtme modunda kutu ekran görüntüsüne girer; orijinali okumak için çok kısa süre gizle.
        // Örtmeme modunda kutu çerçevenin dışında durur, gizlemeye gerek yok, titreme olmaz.
        val probe = cover && boxShown
        var img: Image? = null
        if (probe) {
            main.post { box?.visibility = View.INVISIBLE }
            Thread.sleep(90)
            img = grab(rd)
            val t0 = SystemClock.uptimeMillis()
            while (img == null && SystemClock.uptimeMillis() - t0 < 300) {
                Thread.sleep(25)
                img = grab(rd)
            }
            main.post { if (boxShown) box?.visibility = View.VISIBLE }
        } else {
            img = grab(rd)
        }

        val got: Image? = img
        val newRegion: Bitmap? = if (got != null) {
            try {
                crop(got, fr)
            } finally {
                got.close()
            }
        } else null
        if (newRegion != null) {
            lastRegion?.recycle()
            lastRegion = newRegion
        }
        val region = lastRegion ?: return
        // Ekran sabitse yeni kare gelmez; o durumda önceki kareyi ve imzayı kullan
        val sig = if (newRegion != null) signature(region) else (prevSig ?: return)
        prevSig = sig

        if (newRegion != null) {
            var s = 0L
            for (v in sig) s += v
            if (s / sig.size < 2) blackCount++ else blackCount = 0
            if (blackCount == 8) setNote("Görüntü siyah geliyor: bu uygulama ekran yakalamayı engelliyor olabilir")
        }

        val last = doneSig
        val regionChanged = last == null || diffCount(sig, last) >= 3
        if (!regionChanged) {
            // Görüntü aynı kaldı: bekleyen aday varsa iki okuma aynı sayılır
            if (candCount == 1 && candNorm.isNotEmpty()) {
                candCount = 2
                commitCandidate(fr)
            }
            return
        }
        doneSig = sig

        val res = try {
            ocr.recognize(region, prefs.srcLang)
        } catch (e: Exception) {
            Log.w(TAG, "ocr", e)
            doneSig = null
            return
        }
        val lines = res.textBlocks.flatMap { it.lines }
            .filter { l -> l.boundingBox != null && l.text.count { c -> c.isLetter() } >= 2 }
        if (lines.isEmpty()) {
            onEmptyReading()
            return
        }
        val sorted = lines.sortedBy { it.boundingBox!!.top }
        val text = sorted.joinToString(" ") { it.text.replace('\n', ' ') }.trim()
        val norm = normalize(text)
        if (norm.length < 3) {
            onEmptyReading()
            return
        }
        emptyCount = 0
        val rect = Rect(sorted[0].boundingBox!!)
        sorted.forEach { rect.union(it.boundingBox!!) }
        rect.offset(cropLeft, cropTop)
        setNote("Okunan: " + text.take(40))

        // Zaten gösterilen altyazı (ya da kendi Türkçe kutumuz okunduysa) tekrar çevrilmez
        if (shownNorm.isNotEmpty() && (similar(norm, shownNorm) || similar(norm, shownTextNorm))) {
            candNorm = ""
            candCount = 0
            if (cover && boxShown && moved(rect)) showBox(shownText, rect, fr)
            return
        }

        // Aynı yeni metni iki okumada üst üste görürsek çevir. Tek seferlik yanlış okumalar elenir.
        if (candNorm.isNotEmpty() && similar(norm, candNorm)) {
            candCount++
        } else {
            candNorm = norm
            candCount = 1
        }
        candText = text
        candRect = rect
        if (candCount >= 2) commitCandidate(fr)
    }

    /** Okuma boş geldi. Kutuyu hemen silme, birkaç boş okuma üst üste gelirse sil. */
    private fun onEmptyReading() {
        candNorm = ""
        candCount = 0
        emptyCount++
        setNote("Çerçevede yazı bulunamadı")
        val limit = if (prefs.cover) 2 else 3
        if (emptyCount >= limit) clearBox()
    }

    private fun commitCandidate(fr: Rect) {
        val text = candText
        val norm = candNorm
        val rect = Rect(candRect)
        candNorm = ""
        candCount = 0
        if (text.isEmpty()) return
        val tr = try {
            hub.translate(text, prefs.srcLang)
        } catch (e: Exception) {
            Log.w(TAG, "translate", e)
            setNote("Çeviri hatası: ${e.message ?: "bilinmiyor"}")
            doneSig = null
            return
        }
        shownNorm = norm
        shownText = tr
        shownTextNorm = normalize(tr)
        showBox(tr, rect, fr)
    }

    private fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    /** İki metin yüzde 78'den fazla benziyorsa aynı sayılır. OCR'ın harf hatalarını tolere eder. */
    private fun similar(a: String, b: String): Boolean {
        if (a == b) return true
        val n = max(a.length, b.length)
        if (n == 0) return true
        if (abs(a.length - b.length) > n * 0.3) return false
        return 1.0 - lev(a, b).toDouble() / n >= 0.78
    }

    private fun lev(a: String, b: String): Int {
        val x = a.take(300)
        val y = b.take(300)
        var prev = IntArray(y.length + 1) { it }
        var cur = IntArray(y.length + 1)
        for (i in 1..x.length) {
            cur[0] = i
            for (j in 1..y.length) {
                val cost = if (x[i - 1] == y[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[y.length]
    }

    private fun moved(r: Rect): Boolean =
        abs(r.centerX() - lastRect.centerX()) > 20 ||
            abs(r.bottom - lastRect.bottom) > 20 ||
            abs(r.width() - lastRect.width()) > 40

    private fun resetReading() {
        lastRegion?.recycle()
        lastRegion = null
        prevSig = null
        doneSig = null
        blackCount = 0
        emptyCount = 0
        candNorm = ""
        candCount = 0
        shownNorm = ""
        shownTextNorm = ""
        shownText = ""
    }

    /** Kaydedilen çerçeveyi ekran piksellerine çevirir. Yatay ve dikey için ayrı çerçeve tutulur. */
    private fun frameRect(): Rect? {
        if (capW <= 0 || capH <= 0) return null
        val f = prefs.frame(capW > capH) ?: return null
        val l = (f[0] * capW).toInt().coerceIn(0, capW - 1)
        val t = (f[1] * capH).toInt().coerceIn(0, capH - 1)
        val r = ((f[0] + f[2]) * capW).toInt().coerceIn(l + 1, capW)
        val b = ((f[1] + f[3]) * capH).toInt().coerceIn(t + 1, capH)
        return Rect(l, t, r, b)
    }

    /** Yakalanan kareden sadece çerçevenin içini keser. */
    private fun crop(img: Image, fr: Rect): Bitmap {
        val plane = img.planes[0]
        val rowPixels = plane.rowStride / plane.pixelStride
        val wide = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(plane.buffer)

        val minS = 48
        var l = fr.left
        var t = fr.top
        var r = fr.right
        var b = fr.bottom
        if (r - l < minS) {
            l = (l + r) / 2 - minS / 2
            r = l + minS
        }
        if (b - t < minS) {
            t = (t + b) / 2 - minS / 2
            b = t + minS
        }
        l = l.coerceIn(0, img.width - minS)
        r = r.coerceIn(l + minS, img.width)
        t = t.coerceIn(0, img.height - minS)
        b = b.coerceIn(t + minS, img.height)
        cropLeft = l
        cropTop = t
        val out = Bitmap.createBitmap(wide, l, t, r - l, b - t)
        if (out !== wide) wide.recycle()
        return out
    }

    /** 64x16 ızgarada ortalama parlaklık. Küçük harf değişikliklerini yakalar, her pikseli karşılaştırmaz. */
    private fun signature(b: Bitmap): IntArray {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val cols = 64
        val rows = 16
        val sum = LongArray(cols * rows)
        val cnt = IntArray(cols * rows)
        var y = 0
        while (y < h) {
            val r = y * rows / h
            var x = 0
            while (x < w) {
                val c = x * cols / w
                val p = px[y * w + x]
                val lum = ((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)
                sum[r * cols + c] += lum.toLong()
                cnt[r * cols + c]++
                x += 2
            }
            y += 2
        }
        return IntArray(cols * rows) { (sum[it] / (10L * max(1, cnt[it]))).toInt() }
    }

    private fun diffCount(a: IntArray, b: IntArray): Int {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 14) n++
        return n
    }

    // ---------- Pencereler ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    /**
     * Pencere koordinatı ile gerçek ekran koordinatı arasında kayma olabilir (durum çubuğu, çentik).
     * Pencere ekrana eklenince gerçek yerini ölçüp farkı hatırlarız, böylece her şey ekran pikseliyle hizalı kalır.
     */
    private fun measureOrigin(v: View, lp: WindowManager.LayoutParams) {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val nx = loc[0] - lp.x
        val ny = loc[1] - lp.y
        if (nx == originX && ny == originY) return
        val dx = originX - nx
        val dy = originY - ny
        originX = nx
        originY = ny
        lp.x += dx
        lp.y += dy
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
            Log.w(TAG, "origin", e)
        }
    }

    // ---------- Çerçeve düzenleyici ----------

    private fun toggleEditor() {
        if (editor == null) openEditor() else saveEditor()
    }

    private fun openEditor() {
        if (editor != null) return
        editing = true
        clearBox()
        val landscape = capW > capH
        val f = prefs.frame(landscape)
            ?: if (landscape) floatArrayOf(0.10f, 0.72f, 0.80f, 0.18f) else floatArrayOf(0.08f, 0.68f, 0.84f, 0.14f)
        val lp = overlayParams(true)
        lp.width = (f[2] * capW).toInt().coerceAtLeast(dp(150))
        lp.height = (f[3] * capH).toInt().coerceAtLeast(dp(56))
        lp.x = (f[0] * capW).toInt() - originX
        lp.y = (f[1] * capH).toInt() - originY
        val fv = FrameView(this, object : FrameView.Callbacks {
            override fun onMove(dx: Int, dy: Int) = moveEditor(dx, dy)
            override fun onResize(dw: Int, dh: Int) = resizeEditor(dw, dh)
            override fun onSave() = saveEditor()
        })
        try {
            wm.addView(fv, lp)
            editor = fv
            editLp = lp
            fv.post { measureOrigin(fv, lp) }
            notifyNow()
            Toast.makeText(
                this,
                "Çerçeveyi altyazının üstüne sürükle, sağ alttaki daireden boyutlandır, Kaydet'e bas",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Log.e(TAG, "editor", e)
            editing = false
            setNote("Çerçeve açılamadı: 'Üstte göster' izni açık mı?")
        }
    }

    private fun moveEditor(dx: Int, dy: Int) {
        val v = editor ?: return
        val lp = editLp ?: return
        val sx = (lp.x + originX + dx).coerceIn(0, max(0, capW - lp.width))
        val sy = (lp.y + originY + dy).coerceIn(0, max(0, capH - lp.height))
        lp.x = sx - originX
        lp.y = sy - originY
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
            Log.w(TAG, "move", e)
        }
    }

    private fun resizeEditor(dw: Int, dh: Int) {
        val v = editor ?: return
        val lp = editLp ?: return
        val minW = dp(150)
        val minH = dp(56)
        val sx = lp.x + originX
        val sy = lp.y + originY
        lp.width = (lp.width + dw).coerceIn(minW, max(minW, capW - sx))
        lp.height = (lp.height + dh).coerceIn(minH, max(minH, capH - sy))
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
            Log.w(TAG, "resize", e)
        }
    }

    private fun saveEditor() {
        val v = editor ?: return
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        if (capW > 0 && capH > 0 && v.width > 0 && v.height > 0) {
            prefs.setFrame(
                capW > capH,
                floatArrayOf(
                    loc[0].toFloat() / capW,
                    loc[1].toFloat() / capH,
                    v.width.toFloat() / capW,
                    v.height.toFloat() / capH
                )
            )
            Toast.makeText(this, "Çerçeve kaydedildi", Toast.LENGTH_SHORT).show()
        }
        closeEditor()
    }

    private fun closeEditor() {
        editor?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                Log.w(TAG, "rm editor", e)
            }
        }
        editor = null
        editLp = null
        editing = false
        worker?.post { resetReading() }
        note = "Çalışıyor"
        notifyNow()
    }

    // ---------- Çeviri kutusu ----------

    private fun createBox(): TextView {
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(10), dp(6), dp(10), dp(6))
        tv.layoutParams = overlayParams(false)
        return tv
    }

    /**
     * Örtmeme modu (varsayılan): kutu çerçevenin hemen üstünde, sığmazsa hemen altında durur.
     * Çerçevenin içine girmediği için ekran görüntüsünü bozmaz, titreme olmaz, konum hep aynıdır.
     * Örtme modu: kutu okunan altyazı satırlarının üstüne oturur ve orijinali örter.
     */
    private fun showBox(text: String, textRect: Rect, fr: Rect) {
        val tr = Rect(textRect)
        val frame = Rect(fr)
        main.post {
            try {
                val cover = prefs.cover
                val firstTime = box == null
                val tv = box ?: createBox().also { box = it }
                val bg = GradientDrawable()
                bg.cornerRadius = dp(12).toFloat()
                bg.setColor(Color.argb(prefs.bgAlpha * 255 / 100, 12, 12, 16))
                bg.setStroke(dp(1), Color.argb(70, 255, 255, 255))
                tv.background = bg
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.textSp.toFloat())
                tv.text = text

                val pad = dp(10)
                val w: Int
                if (cover) {
                    w = max(tr.width() + 2 * pad, (capW * 0.3f).toInt()).coerceAtMost(capW - dp(8))
                    tv.minHeight = tr.height() + dp(12)
                } else {
                    w = max(frame.width(), (capW * 0.45f).toInt()).coerceAtMost(capW - dp(8))
                    tv.minHeight = 0
                }
                val lp = tv.layoutParams as WindowManager.LayoutParams
                lp.width = w
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT
                tv.measure(
                    View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                val h = tv.measuredHeight

                val sx: Int
                val sy: Int
                if (cover) {
                    sx = tr.centerX() - w / 2
                    sy = tr.bottom + dp(6) - h
                } else {
                    sx = frame.centerX() - w / 2
                    val above = frame.top - dp(6) - h
                    sy = if (above >= 0) above else frame.bottom + dp(6)
                }
                lp.x = sx.coerceIn(0, max(0, capW - w)) - originX
                lp.y = sy.coerceIn(0, max(0, capH - h)) - originY

                if (tv.parent == null) {
                    wm.addView(tv, lp)
                    if (firstTime) tv.post { measureOrigin(tv, lp) }
                } else {
                    wm.updateViewLayout(tv, lp)
                }
                tv.visibility = View.VISIBLE
                lastRect = tr
                boxShown = true
            } catch (e: Exception) {
                Log.e(TAG, "showBox", e)
                note = "Kutu gösterilemedi: 'Üstte göster' izni açık mı?"
                notifyNow()
            }
        }
    }

    private fun clearBox() {
        shownNorm = ""
        shownTextNorm = ""
        shownText = ""
        main.post {
            box?.let {
                if (it.parent != null) {
                    try {
                        wm.removeView(it)
                    } catch (e: Exception) {
                        Log.w(TAG, "removeView", e)
                    }
                }
            }
            boxShown = false
        }
    }

    // ---------- Bildirim ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ceviri", "Oyun Çeviri", NotificationManager.IMPORTANCE_LOW))
    }

    private fun setNote(n: String) {
        if (n == note) return
        note = n
        main.post { notifyNow() }
    }

    private fun buildNotif(): Notification {
        fun pi(action: String, code: Int): PendingIntent = PendingIntent.getService(
            this, code,
            Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val txt = if (paused) "Duraklatıldı" else note
        val b = Notification.Builder(this, "ceviri")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Oyun Çeviri")
            .setContentText(txt)
            .setStyle(Notification.BigTextStyle().bigText(txt))
            .setOngoing(true)
        b.addAction(Notification.Action.Builder(null, if (editor != null) "Kaydet" else "Çerçeve", pi(ACTION_FRAME, 3)).build())
        b.addAction(Notification.Action.Builder(null, if (paused) "Devam" else "Duraklat", pi(ACTION_TOGGLE, 1)).build())
        b.addAction(Notification.Action.Builder(null, "Durdur", pi(ACTION_STOP, 2)).build())
        return b.build()
    }

    private fun notifyNow() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotif())
    }

    // ---------- Kapanış ----------

    override fun onDestroy() {
        running = false
        worker?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        try { vd?.release() } catch (e: Exception) { Log.w(TAG, "vd", e) }
        reader?.close()
        try { projection?.stop() } catch (e: Exception) { Log.w(TAG, "mp", e) }
        box?.let {
            if (it.parent != null) {
                try { wm.removeView(it) } catch (e: Exception) { Log.w(TAG, "rm", e) }
            }
        }
        editor?.let {
            try { wm.removeView(it) } catch (e: Exception) { Log.w(TAG, "rm2", e) }
        }
        editor = null
        boxShown = false
        editing = false
        lastRegion?.recycle()
        ocr.close()
        hub.close()
        super.onDestroy()
    }
}
